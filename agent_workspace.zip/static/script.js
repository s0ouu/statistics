/**
 * Co-Statistics JavaScript 機能
 * 作成者: MiniMax Agent
 */

class CoStatistics {
    constructor() {
        this.currentData = null;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadAnalysisHistory();
        this.loadRecommendations();
    }

    setupEventListeners() {
        // ファイルアップロード関連
        const fileUploadArea = document.getElementById('fileUploadArea');
        const fileInput = document.getElementById('fileInput');
        const uploadBtn = document.getElementById('uploadBtn');
        const previewBtn = document.getElementById('previewBtn');

        // ドラッグ&ドロップ
        fileUploadArea.addEventListener('click', () => fileInput.click());
        fileUploadArea.addEventListener('dragover', this.handleDragOver.bind(this));
        fileUploadArea.addEventListener('dragleave', this.handleDragLeave.bind(this));
        fileUploadArea.addEventListener('drop', this.handleDrop.bind(this));

        fileInput.addEventListener('change', this.handleFileSelect.bind(this));
        uploadBtn.addEventListener('click', this.uploadFile.bind(this));
        previewBtn.addEventListener('click', this.showDataPreview.bind(this));

        // ナビゲーションメニュー
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', this.handleNavigation.bind(this));
        });

        // データクリーニング
        document.getElementById('cleaningBtn').addEventListener('click', this.performDataCleaning.bind(this));

        // モーダル関連
        document.getElementById('closeModal').addEventListener('click', this.closeModal.bind(this));
        document.getElementById('cancelBtn').addEventListener('click', this.closeModal.bind(this));
        document.getElementById('executeBtn').addEventListener('click', this.executeAnalysis.bind(this));

        // 推奨分析のクリック
        document.getElementById('recommendations').addEventListener('click', this.handleRecommendationClick.bind(this));

        // 履歴のクリック
        document.getElementById('historyList').addEventListener('click', this.handleHistoryClick.bind(this));
    }

    // ファイル関連のハンドラー
    handleDragOver(e) {
        e.preventDefault();
        e.currentTarget.classList.add('dragover');
    }

    handleDragLeave(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
    }

    handleDrop(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            document.getElementById('fileInput').files = files;
            this.updateFileInfo(files[0]);
        }
    }

    handleFileSelect(e) {
        const file = e.target.files[0];
        if (file) {
            this.updateFileInfo(file);
        }
    }

    updateFileInfo(file) {
        const fileInfo = document.getElementById('fileInfo');
        const fileUploadArea = document.getElementById('fileUploadArea');
        
        fileUploadArea.innerHTML = `
            <div class="upload-icon">📄</div>
            <p><strong>${file.name}</strong></p>
            <p>サイズ: ${this.formatFileSize(file.size)}</p>
            <p>種類: ${file.type || '不明'}</p>
        `;
        
        fileInfo.style.display = 'block';
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    async uploadFile() {
        const fileInput = document.getElementById('fileInput');
        const file = fileInput.files[0];

        if (!file) {
            this.showAlert('ファイルを選択してください', 'error');
            return;
        }

        const formData = new FormData();
        formData.append('file', file);

        try {
            this.setLoading('uploadBtn', true);
            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                this.currentData = result.data_info;
                this.showAlert('ファイルが正常にアップロードされました', 'success');
                this.showFileSteps();
                this.loadRecommendations();
            } else {
                this.showAlert(result.error, 'error');
            }
        } catch (error) {
            this.showAlert('アップロードエラー: ' + error.message, 'error');
        } finally {
            this.setLoading('uploadBtn', false);
        }
    }

    showFileSteps() {
        document.querySelector('.welcome-screen .welcome-icon').style.display = 'none';
        document.querySelector('.welcome-screen h2').style.display = 'none';
        document.querySelector('.welcome-screen p').style.display = 'none';
        document.getElementById('fileSteps').style.display = 'block';
    }

    async showDataPreview() {
        if (!this.currentData) {
            this.showAlert('データが読み込まれていません', 'error');
            return;
        }

        const dataPreview = document.getElementById('dataPreview');
        const previewTable = document.getElementById('previewTable');

        // テーブルのヘッダーを作成
        let tableHTML = '<thead><tr>';
        this.currentData.column_names.forEach(col => {
            tableHTML += `<th>${col}</th>`;
        });
        tableHTML += '</tr></thead><tbody>';

        // データ行を追加
        this.currentData.preview.forEach(row => {
            tableHTML += '<tr>';
            this.currentData.column_names.forEach(col => {
                const value = row[col] !== null && row[col] !== undefined ? row[col] : '-';
                tableHTML += `<td>${value}</td>`;
            });
            tableHTML += '</tr>';
        });
        tableHTML += '</tbody>';

        previewTable.innerHTML = tableHTML;
        dataPreview.style.display = 'block';
        dataPreview.scrollIntoView({ behavior: 'smooth' });
    }

    // ナビゲーション処理
    handleNavigation(e) {
        // アクティブなボタンを更新
        document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');

        const section = e.target.dataset.section;
        
        if (!this.currentData) {
            this.showAlert('まずデータを読み込んでください', 'error');
            return;
        }

        switch (section) {
            case 'basic':
                this.showBasicStatsModal();
                break;
            case 'ttest':
                this.showTTestModal();
                break;
            case 'regression':
                this.showRegressionModal();
                break;
            case 'report':
                this.generateReport();
                break;
            default:
                this.showAlert('この機能は準備中です', 'info');
        }
    }

    // モーダル表示用のメソッド
    showBasicStatsModal() {
        const modal = document.getElementById('analysisModal');
        const modalTitle = document.getElementById('modalTitle');
        const modalBody = document.getElementById('modalBody');

        modalTitle.textContent = '基本統計分析';
        modalBody.innerHTML = `
            <p>データの基本統計量を計算し、グラフを作成します。</p>
            <div class="form-group">
                <label>分析対象:</label>
                <p>全ての数値列 (${this.currentData.column_names.filter(col => 
                    ['int64', 'float64', 'int32', 'float32'].includes(this.currentData.dtypes[col])
                ).join(', ')})</p>
            </div>
        `;

        document.getElementById('executeBtn').dataset.analysis = 'basic_stats';
        modal.style.display = 'flex';
    }

    async showTTestModal() {
        const columns = await this.getNumericColumns();
        
        const modal = document.getElementById('analysisModal');
        const modalTitle = document.getElementById('modalTitle');
        const modalBody = document.getElementById('modalBody');

        modalTitle.textContent = 't検定分析';
        modalBody.innerHTML = `
            <div class="form-group">
                <label for="testType">検定の種類:</label>
                <select id="testType">
                    <option value="one_sample">一標本t検定</option>
                    <option value="two_sample">二標本t検定</option>
                </select>
            </div>
            <div class="form-group">
                <label for="column1">分析列1:</label>
                <select id="column1">
                    ${columns.map(col => `<option value="${col}">${col}</option>`).join('')}
                </select>
            </div>
            <div class="form-group" id="column2Group" style="display: none;">
                <label for="column2">分析列2:</label>
                <select id="column2">
                    ${columns.map(col => `<option value="${col}">${col}</option>`).join('')}
                </select>
            </div>
            <div class="form-group" id="testValueGroup">
                <label for="testValue">検定値:</label>
                <input type="number" id="testValue" value="0" step="any">
            </div>
        `;

        // 検定タイプの変更イベント
        document.getElementById('testType').addEventListener('change', (e) => {
            const isTwoSample = e.target.value === 'two_sample';
            document.getElementById('column2Group').style.display = isTwoSample ? 'block' : 'none';
            document.getElementById('testValueGroup').style.display = isTwoSample ? 'none' : 'block';
        });

        document.getElementById('executeBtn').dataset.analysis = 't_test';
        modal.style.display = 'flex';
    }

    async showRegressionModal() {
        const columns = await this.getNumericColumns();
        
        const modal = document.getElementById('analysisModal');
        const modalTitle = document.getElementById('modalTitle');
        const modalBody = document.getElementById('modalBody');

        modalTitle.textContent = '回帰分析';
        modalBody.innerHTML = `
            <div class="form-group">
                <label for="xColumn">説明変数 (X):</label>
                <select id="xColumn">
                    ${columns.map(col => `<option value="${col}">${col}</option>`).join('')}
                </select>
            </div>
            <div class="form-group">
                <label for="yColumn">目的変数 (Y):</label>
                <select id="yColumn">
                    ${columns.map(col => `<option value="${col}">${col}</option>`).join('')}
                </select>
            </div>
        `;

        document.getElementById('executeBtn').dataset.analysis = 'regression';
        modal.style.display = 'flex';
    }

    closeModal() {
        document.getElementById('analysisModal').style.display = 'none';
    }

    async executeAnalysis() {
        const analysisType = document.getElementById('executeBtn').dataset.analysis;
        
        try {
            this.setLoading('executeBtn', true);
            
            let result;
            switch (analysisType) {
                case 'basic_stats':
                    result = await this.performBasicStats();
                    break;
                case 't_test':
                    result = await this.performTTest();
                    break;
                case 'regression':
                    result = await this.performRegression();
                    break;
            }

            if (result && result.success) {
                this.displayAnalysisResult(result);
                this.closeModal();
                this.loadAnalysisHistory();
                this.loadRecommendations();
            } else {
                this.showAlert(result ? result.error : '分析に失敗しました', 'error');
            }
        } catch (error) {
            this.showAlert('分析エラー: ' + error.message, 'error');
        } finally {
            this.setLoading('executeBtn', false);
        }
    }

    async performBasicStats() {
        const response = await fetch('/api/basic_stats', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        return await response.json();
    }

    async performTTest() {
        const testType = document.getElementById('testType').value;
        const column1 = document.getElementById('column1').value;
        const column2 = document.getElementById('column2').value;
        const testValue = parseFloat(document.getElementById('testValue').value);

        const data = {
            test_type: testType,
            column1: column1,
            column2: column2,
            test_value: testValue
        };

        const response = await fetch('/api/t_test', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        return await response.json();
    }

    async performRegression() {
        const xColumn = document.getElementById('xColumn').value;
        const yColumn = document.getElementById('yColumn').value;

        const data = {
            x_column: xColumn,
            y_column: yColumn
        };

        const response = await fetch('/api/regression', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        return await response.json();
    }

    displayAnalysisResult(result) {
        const analysisResult = document.getElementById('analysisResult');
        const resultTitle = document.getElementById('resultTitle');
        const resultContent = document.getElementById('resultContent');
        const resultChart = document.getElementById('resultChart');

        resultTitle.textContent = '分析結果';
        
        // 結果の内容を表示
        if (result.stats) {
            // 基本統計の場合
            let html = '<h4>基本統計量</h4><table class="stats-table"><thead><tr><th>統計量</th>';
            Object.keys(result.stats).forEach(col => {
                html += `<th>${col}</th>`;
            });
            html += '</tr></thead><tbody>';

            const statLabels = {
                'count': 'データ数',
                'mean': '平均',
                'std': '標準偏差',
                'min': '最小値',
                '25%': '第1四分位数',
                '50%': '中央値',
                '75%': '第3四分位数',
                'max': '最大値'
            };

            Object.keys(statLabels).forEach(stat => {
                html += `<tr><td>${statLabels[stat]}</td>`;
                Object.keys(result.stats).forEach(col => {
                    const value = result.stats[col][stat];
                    html += `<td>${typeof value === 'number' ? value.toFixed(3) : value}</td>`;
                });
                html += '</tr>';
            });
            html += '</tbody></table>';
            resultContent.innerHTML = html;
        }

        if (result.results) {
            // t検定または回帰分析の場合
            let html = '<h4>分析結果</h4><div class="result-summary">';
            Object.keys(result.results).forEach(key => {
                const value = result.results[key];
                const displayValue = typeof value === 'number' ? value.toFixed(4) : value;
                html += `<p><strong>${this.translateResultKey(key)}:</strong> ${displayValue}</p>`;
            });
            html += '</div>';
            resultContent.innerHTML = html;
        }

        // グラフを表示
        if (result.chart_url) {
            resultChart.innerHTML = `<img src="${result.chart_url}" alt="分析結果グラフ" />`;
        }

        analysisResult.style.display = 'block';
        analysisResult.scrollIntoView({ behavior: 'smooth' });
    }

    translateResultKey(key) {
        const translations = {
            't_statistic': 't統計量',
            'p_value': 'p値',
            'significance': '有意性',
            'description': '検定内容',
            'coefficient': '回帰係数',
            'intercept': '切片',
            'r_squared': '決定係数',
            'correlation': '相関係数',
            'equation': '回帰式'
        };
        return translations[key] || key;
    }

    async performDataCleaning() {
        const operations = [];
        
        if (document.getElementById('missingValuesCheck').checked) {
            operations.push('remove_missing');
        }
        
        if (document.getElementById('outliersCheck').checked) {
            operations.push('remove_outliers');
        }

        if (operations.length === 0) {
            this.showAlert('クリーニング項目を選択してください', 'error');
            return;
        }

        try {
            this.setLoading('cleaningBtn', true);
            
            for (const operation of operations) {
                const response = await fetch('/api/data_cleaning', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ operation: operation })
                });

                const result = await response.json();
                if (result.success) {
                    this.currentData = result.data_info;
                    this.showAlert(result.message, 'success');
                } else {
                    this.showAlert(result.error, 'error');
                }
            }
            
            this.loadRecommendations();
        } catch (error) {
            this.showAlert('クリーニングエラー: ' + error.message, 'error');
        } finally {
            this.setLoading('cleaningBtn', false);
        }
    }

    async loadAnalysisHistory() {
        try {
            const response = await fetch('/api/history');
            const result = await response.json();

            if (result.success) {
                this.displayAnalysisHistory(result.history);
            }
        } catch (error) {
            console.error('履歴読み込みエラー:', error);
        }
    }

    displayAnalysisHistory(history) {
        const historyList = document.getElementById('historyList');
        
        if (history.length === 0) {
            historyList.innerHTML = '<p class="no-history">分析履歴がありません</p>';
            return;
        }

        let html = '';
        history.slice().reverse().forEach(item => {
            html += `
                <div class="history-item" data-id="${item.id}">
                    <div class="history-type">${item.type}</div>
                    <div class="history-time">${item.timestamp}</div>
                    <div class="history-summary">${item.summary}</div>
                </div>
            `;
        });

        historyList.innerHTML = html;
    }

    async loadRecommendations() {
        try {
            const response = await fetch('/api/recommendations');
            const result = await response.json();

            if (result.success) {
                this.displayRecommendations(result.recommendations);
            }
        } catch (error) {
            console.error('レコメンデーション読み込みエラー:', error);
        }
    }

    displayRecommendations(recommendations) {
        const recommendationsContainer = document.getElementById('recommendations');
        
        if (recommendations.length === 0) {
            recommendationsContainer.innerHTML = '<p class="no-recommendations">データを読み込むとレコメンデーションが表示されます</p>';
            return;
        }

        let html = '';
        recommendations.forEach(rec => {
            html += `
                <div class="recommendation-card ${rec.priority}-priority" data-type="${rec.type}">
                    <div class="recommendation-title">${rec.title}</div>
                    <div class="recommendation-description">${rec.description}</div>
                </div>
            `;
        });

        recommendationsContainer.innerHTML = html;
    }

    handleRecommendationClick(e) {
        const card = e.target.closest('.recommendation-card');
        if (!card) return;

        const type = card.dataset.type;
        
        switch (type) {
            case '基本統計':
                this.showBasicStatsModal();
                break;
            case '回帰分析':
                this.showRegressionModal();
                break;
            case 'データクリーニング':
                // データクリーニングセクションにスクロール
                document.querySelector('.cleaning-options').scrollIntoView({ behavior: 'smooth' });
                break;
        }
    }

    handleHistoryClick(e) {
        const item = e.target.closest('.history-item');
        if (!item) return;

        // 履歴項目がクリックされた時の処理
        // 例: 分析結果を再表示
        this.showAlert('履歴項目がクリックされました', 'info');
    }

    async getNumericColumns() {
        try {
            const response = await fetch('/api/columns');
            const result = await response.json();
            return result.success ? result.numeric_columns : [];
        } catch (error) {
            console.error('列情報取得エラー:', error);
            return [];
        }
    }

    // ユーティリティメソッド
    showAlert(message, type = 'info') {
        // 簡単なアラート表示（実際のプロジェクトではより洗練されたものを使用）
        const alertClass = type === 'success' ? 'text-success' : 
                          type === 'error' ? 'text-error' : '';
        
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert ${alertClass}`;
        alertDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 1001;
            max-width: 300px;
        `;
        alertDiv.textContent = message;
        
        document.body.appendChild(alertDiv);
        
        setTimeout(() => {
            alertDiv.remove();
        }, 3000);
    }

    setLoading(buttonId, isLoading) {
        const button = document.getElementById(buttonId);
        if (isLoading) {
            button.classList.add('loading');
            button.disabled = true;
        } else {
            button.classList.remove('loading');
            button.disabled = false;
        }
    }

    generateReport() {
        this.showAlert('レポート機能は準備中です', 'info');
    }
}

// アプリケーションの初期化
document.addEventListener('DOMContentLoaded', () => {
    new CoStatistics();
});
