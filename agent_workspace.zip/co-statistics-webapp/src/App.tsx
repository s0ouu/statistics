import React, { useState } from 'react';
import { BarChart3, Upload, TrendingUp, Calculator, FileText, Activity } from 'lucide-react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';
import { StatisticsProvider } from './contexts/StatisticsContext';
import './App.css';

function App() {
  const [activeTab, setActiveTab] = useState('basic');

  return (
    <StatisticsProvider>
      <div className="min-h-screen bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-800">
        <div className="flex flex-col h-screen">
          {/* Header */}
          <Header activeTab={activeTab} onTabChange={setActiveTab} />
          
          {/* Main Layout */}
          <div className="flex flex-1 overflow-hidden">
            {/* Sidebar */}
            <Sidebar />
            
            {/* Main Content Area */}
            <MainContent activeTab={activeTab} />
          </div>
        </div>
      </div>
    </StatisticsProvider>
  );
}

export default App;
