import React from 'react';
import { Upload, Database, Wrench, History, Sparkles } from 'lucide-react';
import FileUpload from './FileUpload';
import DataCleaning from './DataCleaning';
import AnalysisHistory from './AnalysisHistory';
import { useStatistics } from '../contexts/StatisticsContext';

const Sidebar: React.FC = () => {
  const { currentData } = useStatistics();

  return (
    <aside className="w-80 bg-white/90 backdrop-blur-sm shadow-xl border-r border-white/20 overflow-y-auto">
      <div className="p-6 space-y-6">
        {/* Data Management Section */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100">
          <div className="flex items-center space-x-2 mb-4">
            <Database className="text-blue-600" size={20} />
            <h3 className="text-lg font-semibold text-gray-800">データ管理</h3>
          </div>
          <FileUpload />
        </div>

        {/* Data Cleaning Section */}
        {currentData && (
          <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-4 border border-purple-100">
            <div className="flex items-center space-x-2 mb-4">
              <Wrench className="text-purple-600" size={20} />
              <h3 className="text-lg font-semibold text-gray-800">データクリーニング</h3>
            </div>
            <DataCleaning />
          </div>
        )}

        {/* Analysis History Section */}
        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4 border border-green-100">
          <div className="flex items-center space-x-2 mb-4">
            <History className="text-green-600" size={20} />
            <h3 className="text-lg font-semibold text-gray-800">分析履歴</h3>
          </div>
          <AnalysisHistory />
        </div>

        {/* Recommendations Section */}
        <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-xl p-4 border border-yellow-100">
          <div className="flex items-center space-x-2 mb-4">
            <Sparkles className="text-yellow-600" size={20} />
            <h3 className="text-lg font-semibold text-gray-800">レコメンデーション</h3>
          </div>
          <div className="space-y-2">
            {currentData ? (
              <>
                <div className="text-sm text-gray-600 bg-white/50 rounded-lg p-3">
                  <div className="font-medium text-gray-800 mb-1">推奨分析:</div>
                  <ul className="space-y-1 text-xs">
                    <li>• 基本統計で分布を確認</li>
                    <li>• 相関分析で関係性を調査</li>
                    <li>• 散布図で外れ値をチェック</li>
                  </ul>
                </div>
              </>
            ) : (
              <div className="text-sm text-gray-500 italic text-center py-4">
                データを読み込み後に<br />推奨分析が表示されます
              </div>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
