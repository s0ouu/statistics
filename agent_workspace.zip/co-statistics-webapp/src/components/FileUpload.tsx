import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, File, CheckCircle, AlertCircle } from 'lucide-react';
import { useStatistics } from '../contexts/StatisticsContext';
import axios from 'axios';

const FileUpload: React.FC = () => {
  const { 
    currentData, 
    setCurrentData, 
    isLoading, 
    setIsLoading, 
    error, 
    setError 
  } = useStatistics();

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setIsLoading(true);
    setError(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post('http://127.0.0.1:5001/api/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.data.success) {
        setCurrentData(response.data.data_info);
        setError(null);
      } else {
        setError(response.data.error || 'アップロードに失敗しました');
      }
    } catch (error) {
      console.error('Upload error:', error);
      setError('ファイルアップロードエラーが発生しました');
    } finally {
      setIsLoading(false);
    }
  }, [setCurrentData, setIsLoading, setError]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls'],
    },
    multiple: false,
  });

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="space-y-4">
      {/* Upload Area */}
      <div
        {...getRootProps()}
        className={`
          border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200
          ${isDragActive 
            ? 'border-blue-400 bg-blue-50 scale-105' 
            : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50'
          }
          ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}
        `}
      >
        <input {...getInputProps()} />
        <div className="space-y-3">
          {isLoading ? (
            <div className="animate-spin mx-auto w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full"></div>
          ) : (
            <Upload className="mx-auto text-gray-400" size={32} />
          )}
          
          <div>
            <p className="text-sm font-medium text-gray-700">
              {isDragActive
                ? 'ファイルをここにドロップしてください'
                : 'クリックまたはドラッグ&ドロップでファイルを選択'
              }
            </p>
            <p className="text-xs text-gray-500 mt-1">
              対応形式: CSV, Excel (.xlsx, .xls)
            </p>
          </div>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="flex items-start space-x-2 p-3 bg-red-50 border border-red-200 rounded-lg">
          <AlertCircle className="text-red-500 flex-shrink-0 mt-0.5" size={16} />
          <span className="text-sm text-red-700">{error}</span>
        </div>
      )}

      {/* Success Message with Data Info */}
      {currentData && (
        <div className="space-y-3">
          <div className="flex items-center space-x-2 p-3 bg-green-50 border border-green-200 rounded-lg">
            <CheckCircle className="text-green-500 flex-shrink-0" size={16} />
            <span className="text-sm text-green-700 font-medium">
              ファイルが正常にアップロードされました
            </span>
          </div>
          
          <div className="bg-white/50 rounded-lg p-3 border border-gray-200">
            <h4 className="text-sm font-medium text-gray-800 mb-2">データ情報</h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex justify-between">
                <span className="text-gray-600">行数:</span>
                <span className="font-medium">{currentData.rows.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">列数:</span>
                <span className="font-medium">{currentData.columns.toLocaleString()}</span>
              </div>
            </div>
            
            <div className="mt-3">
              <span className="text-xs text-gray-600">列名:</span>
              <div className="mt-1 flex flex-wrap gap-1">
                {currentData.column_names.slice(0, 6).map((name, index) => (
                  <span key={index} className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                    {name}
                  </span>
                ))}
                {currentData.column_names.length > 6 && (
                  <span className="text-xs text-gray-500">
                    +{currentData.column_names.length - 6}個
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      {currentData && (
        <div className="flex space-x-2">
          <button 
            className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm font-medium"
            onClick={() => {/* データプレビュー機能 */}}
          >
            データプレビュー
          </button>
          <button 
            className="flex-1 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors text-sm font-medium"
            onClick={() => setCurrentData(null)}
          >
            リセット
          </button>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
