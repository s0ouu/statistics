import React from 'react';
import { BarChart3, TrendingUp, Calculator, FileText, Activity, Layers } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const navigationItems = [
  { id: 'basic', label: '基本統計', icon: BarChart3 },
  { id: 'ttest', label: 't検定分析', icon: TrendingUp },
  { id: 'covariance', label: '共分散分析', icon: Calculator },
  { id: 'probability', label: '確率分析', icon: Activity },
  { id: 'regression', label: '回帰分析', icon: Layers },
  { id: 'report', label: 'レポート', icon: FileText },
];

const Header: React.FC<HeaderProps> = ({ activeTab, onTabChange }) => {
  return (
    <header className="bg-white/95 backdrop-blur-sm shadow-lg border-b border-white/20">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="text-3xl">📊</div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Co-Statistics
            </h1>
          </div>

          {/* Navigation Menu */}
          <nav className="flex space-x-2">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onTabChange(item.id)}
                  className={`
                    flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all duration-200
                    ${activeTab === item.id
                      ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg transform scale-105'
                      : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
                    }
                  `}
                >
                  <Icon size={18} />
                  <span className="text-sm">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
