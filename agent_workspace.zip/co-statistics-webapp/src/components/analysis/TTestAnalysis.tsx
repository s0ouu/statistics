import React, { useState } from 'react';
import { TrendingUp, Play, Settings, Loader2 } from 'lucide-react';
import { useStatistics } from '../../contexts/StatisticsContext';

const TTestAnalysis: React.FC = () => {
  const { currentData, addAnalysisResult, isLoading, setIsLoading, setError } = useStatistics();
  const [testType, setTestType] = useState('one_sample');
  const [column1, setColumn1] = useState('');
  const [column2, setColumn2] = useState('');
  const [testValue, setTestValue] = useState(0);
  const [result, setResult] = useState<any>(null);

  const numericColumns = currentData?.column_names.filter(col => {
    const dtype = currentData.dtypes[col];
    return dtype.includes('int') || dtype.includes('float');
  }) || [];

  const runTTest = async () => {
    if (!currentData || !column1) return;

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const requestData = {
        column1,
        column2: testType === 'two_sample' ? column2 : undefined,
        test_type: testType,
        test_value: testType === 'one_sample' ? testValue : undefined,
      };

      // Simulate API call - replace with actual API when available
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock result
      const mockResult = {
        success: true,
        analysis_id: Date.now().toString(),
        test_type: testType,
        statistic: Math.random() * 4 - 2,
        p_value: Math.random() * 0.1,
        conclusion: Math.random() > 0.5 ? '統計的に有意' : '統計的に有意でない',
        description: testType === 'one_sample' 
          ? `${column1} の平均が ${testValue} と等しいかの検定`
          : `${column1} と ${column2} の平均値の比較`,
      };

      setResult(mockResult);
      
      addAnalysisResult({
        id: mockResult.analysis_id,
        type: 't検定',
        timestamp: new Date().toISOString(),
        summary: mockResult.description,
      });

    } catch (error) {
      console.error('T-test error:', error);
      setError('t検定分析エラーが発生しました');
    } finally {
      setIsLoading(false);
    }
  };

  const getPValueInterpretation = (pValue: number) => {
    if (pValue < 0.001) return { level: '***', text: '非常に強い有意性', color: 'text-red-600' };
    if (pValue < 0.01) return { level: '**', text: '強い有意性', color: 'text-red-500' };
    if (pValue < 0.05) return { level: '*', text: '有意', color: 'text-orange-500' };
    return { level: 'ns', text: '有意でない', color: 'text-gray-500' };
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <TrendingUp className="text-green-500" size={28} />
          <div>
            <h2 className="text-2xl font-bold text-gray-800">t検定分析</h2>
            <p className="text-gray-600">平均値の統計的検定を実行</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Settings Panel */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-2 mb-4">
              <Settings className="text-gray-500" size={20} />
              <h3 className="text-lg font-semibold text-gray-800">検定設定</h3>
            </div>

            <div className="space-y-4">
              {/* Test Type */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">検定種類</label>
                <select
                  value={testType}
                  onChange={(e) => setTestType(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="one_sample">一標本t検定</option>
                  <option value="two_sample">二標本t検定</option>
                  <option value="paired">対応のあるt検定</option>
                </select>
              </div>

              {/* Column 1 */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {testType === 'one_sample' ? '検定対象列' : '列1'}
                </label>
                <select
                  value={column1}
                  onChange={(e) => setColumn1(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">選択してください</option>
                  {numericColumns.map(col => (
                    <option key={col} value={col}>{col}</option>
                  ))}
                </select>
              </div>

              {/* Column 2 for two-sample test */}
              {(testType === 'two_sample' || testType === 'paired') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">列2</label>
                  <select
                    value={column2}
                    onChange={(e) => setColumn2(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">選択してください</option>
                    {numericColumns.filter(col => col !== column1).map(col => (
                      <option key={col} value={col}>{col}</option>
                    ))}
                  </select>
                </div>
              )}

              {/* Test Value for one-sample test */}
              {testType === 'one_sample' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">検定値</label>
                  <input
                    type="number"
                    value={testValue}
                    onChange={(e) => setTestValue(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="0"
                  />
                </div>
              )}

              {/* Run Button */}
              <button
                onClick={runTTest}
                disabled={!currentData || !column1 || isLoading || 
                  (testType !== 'one_sample' && !column2)}
                className={`
                  w-full flex items-center justify-center space-x-2 py-3 rounded-lg font-medium transition-all duration-200
                  ${currentData && column1 && !isLoading && 
                    (testType === 'one_sample' || column2)
                    ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white hover:from-green-600 hover:to-emerald-600 shadow-lg'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }
                `}
              >
                {isLoading ? (
                  <Loader2 className="animate-spin" size={20} />
                ) : (
                  <Play size={20} />
                )}
                <span>{isLoading ? '分析中...' : 't検定実行'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">分析結果</h3>
            
            {!result ? (
              <div className="text-center py-12">
                <TrendingUp className="mx-auto text-gray-300 mb-4" size={64} />
                <h4 className="text-lg font-medium text-gray-600 mb-2">
                  t検定を実行してください
                </h4>
                <p className="text-gray-500 mb-6">
                  検定設定を選択して「t検定実行」ボタンをクリックしてください
                </p>
                <div className="bg-green-50 rounded-lg p-4 max-w-md mx-auto">
                  <h5 className="font-medium text-green-800 mb-2">t検定について:</h5>
                  <ul className="text-sm text-green-700 space-y-1 text-left">
                    <li>• 一標本: 平均値が特定の値と等しいかを検定</li>
                    <li>• 二標本: 2つのグループの平均値を比較</li>
                    <li>• 対応あり: 同一対象の前後比較</li>
                  </ul>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Test Description */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-medium text-blue-800 mb-2">検定概要</h4>
                  <p className="text-blue-700">{result.description}</p>
                </div>

                {/* Results Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h5 className="font-medium text-gray-800 mb-2">t統計量</h5>
                    <p className="text-2xl font-bold text-gray-700">
                      {result.statistic.toFixed(4)}
                    </p>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h5 className="font-medium text-gray-800 mb-2">p値</h5>
                    <div className="flex items-center space-x-2">
                      <p className="text-2xl font-bold text-gray-700">
                        {result.p_value.toFixed(4)}
                      </p>
                      <span className={`text-sm font-medium ${getPValueInterpretation(result.p_value).color}`}>
                        {getPValueInterpretation(result.p_value).level}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Interpretation */}
                <div className={`rounded-lg p-4 border ${
                  result.p_value < 0.05 
                    ? 'bg-red-50 border-red-200' 
                    : 'bg-gray-50 border-gray-200'
                }`}>
                  <h5 className={`font-medium mb-2 ${
                    result.p_value < 0.05 ? 'text-red-800' : 'text-gray-800'
                  }`}>
                    統計的結論
                  </h5>
                  <p className={`${
                    result.p_value < 0.05 ? 'text-red-700' : 'text-gray-700'
                  }`}>
                    {result.conclusion} (α = 0.05)
                  </p>
                  <p className="text-sm text-gray-600 mt-2">
                    {getPValueInterpretation(result.p_value).text}
                  </p>
                </div>

                {/* Significance Levels Reference */}
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <h5 className="font-medium text-yellow-800 mb-2">有意水準の目安</h5>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                    <div className="text-center">
                      <span className="block font-medium text-red-600">p &lt; 0.001</span>
                      <span className="text-red-700">***</span>
                    </div>
                    <div className="text-center">
                      <span className="block font-medium text-red-500">p &lt; 0.01</span>
                      <span className="text-red-600">**</span>
                    </div>
                    <div className="text-center">
                      <span className="block font-medium text-orange-500">p &lt; 0.05</span>
                      <span className="text-orange-600">*</span>
                    </div>
                    <div className="text-center">
                      <span className="block font-medium text-gray-500">p ≥ 0.05</span>
                      <span className="text-gray-600">ns</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TTestAnalysis;
