import React from 'react';
import { FileText } from 'lucide-react';

const ReportGeneration: React.FC = () => {
  return (
    <div className="p-6">
      <div className="flex items-center space-x-3 mb-6">
        <FileText className="text-green-500" size={28} />
        <div>
          <h2 className="text-2xl font-bold text-gray-800">レポート生成</h2>
          <p className="text-gray-600">分析結果を総合レポートとして出力</p>
        </div>
      </div>
      
      <div className="text-center py-12">
        <FileText className="mx-auto text-gray-300 mb-4" size={64} />
        <h3 className="text-lg font-medium text-gray-600 mb-2">レポート生成</h3>
        <p className="text-gray-500">準備中です...</p>
      </div>
    </div>
  );
};

export default ReportGeneration;
