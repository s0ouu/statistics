import React, { useState, useEffect } from 'react';
import { BarChart3, Play, Download, Eye, Loader2 } from 'lucide-react';
import { useStatistics } from '../../contexts/StatisticsContext';
import axios from 'axios';

const BasicStatistics: React.FC = () => {
  const { 
    currentData, 
    addAnalysisResult, 
    isLoading, 
    setIsLoading, 
    setError 
  } = useStatistics();
  
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [chartUrl, setChartUrl] = useState<string | null>(null);

  const runBasicStats = async () => {
    if (!currentData) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await axios.post('http://127.0.0.1:5001/api/basic_stats', {}, {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.data.success) {
        setAnalysisResult(response.data.stats);
        setChartUrl(response.data.chart_url);
        
        // Add to history
        addAnalysisResult({
          id: response.data.analysis_id,
          type: '基本統計',
          timestamp: new Date().toISOString(),
          chart_url: response.data.chart_url,
          summary: `${Object.keys(response.data.stats).length}個の数値列を分析`,
          stats: response.data.stats,
        });
      } else {
        setError('基本統計分析に失敗しました');
      }
    } catch (error) {
      console.error('Basic stats error:', error);
      setError('統計分析エラーが発生しました');
    } finally {
      setIsLoading(false);
    }
  };

  const downloadChart = () => {
    if (!chartUrl) return;
    
    const link = document.createElement('a');
    link.href = `http://127.0.0.1:5001${chartUrl}`;
    link.download = 'basic_statistics_chart.png';
    link.click();
  };

  const formatNumber = (num: number) => {
    return Number(num).toFixed(2);
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <BarChart3 className="text-blue-500" size={28} />
          <div>
            <h2 className="text-2xl font-bold text-gray-800">基本統計分析</h2>
            <p className="text-gray-600">データの分布、中心傾向、ばらつきを分析</p>
          </div>
        </div>
        
        <button
          onClick={runBasicStats}
          disabled={!currentData || isLoading}
          className={`
            flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-all duration-200
            ${currentData && !isLoading
              ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white hover:from-blue-600 hover:to-indigo-600 shadow-lg hover:shadow-xl'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }
          `}
        >
          {isLoading ? (
            <Loader2 className="animate-spin" size={20} />
          ) : (
            <Play size={20} />
          )}
          <span>{isLoading ? '分析中...' : '分析実行'}</span>
        </button>
      </div>

      {/* Content */}
      {!analysisResult ? (
        <div className="text-center py-12">
          <BarChart3 className="mx-auto text-gray-300 mb-4" size={64} />
          <h3 className="text-lg font-medium text-gray-600 mb-2">
            基本統計分析を開始
          </h3>
          <p className="text-gray-500 mb-6">
            「分析実行」ボタンをクリックしてデータの基本統計量を算出します
          </p>
          <div className="bg-blue-50 rounded-lg p-4 max-w-md mx-auto">
            <h4 className="font-medium text-blue-800 mb-2">分析内容:</h4>
            <ul className="text-sm text-blue-700 space-y-1 text-left">
              <li>• 平均値、中央値、標準偏差</li>
              <li>• 最小値、最大値、四分位数</li>
              <li>• ヒストグラム、散布図</li>
              <li>• 相関マトリックス</li>
            </ul>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Chart Section */}
          {chartUrl && (
            <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-800">分析グラフ</h3>
                <div className="flex space-x-2">
                  <button
                    onClick={downloadChart}
                    className="flex items-center space-x-1 px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                  >
                    <Download size={16} />
                    <span>ダウンロード</span>
                  </button>
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 text-center">
                <img 
                  src={`http://127.0.0.1:5001${chartUrl}`} 
                  alt="Basic Statistics Chart"
                  className="max-w-full h-auto mx-auto rounded-lg shadow-lg"
                />
              </div>
            </div>
          )}

          {/* Statistics Table */}
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">統計量詳細</h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-gray-600">列名</th>
                    <th className="text-center py-3 px-4 font-medium text-gray-600">平均</th>
                    <th className="text-center py-3 px-4 font-medium text-gray-600">標準偏差</th>
                    <th className="text-center py-3 px-4 font-medium text-gray-600">最小値</th>
                    <th className="text-center py-3 px-4 font-medium text-gray-600">最大値</th>
                    <th className="text-center py-3 px-4 font-medium text-gray-600">中央値</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(analysisResult).map(([column, stats]: [string, any], index) => (
                    <tr key={column} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                      <td className="py-3 px-4 font-medium text-gray-800">{column}</td>
                      <td className="py-3 px-4 text-center text-gray-600">{formatNumber(stats.mean)}</td>
                      <td className="py-3 px-4 text-center text-gray-600">{formatNumber(stats.std)}</td>
                      <td className="py-3 px-4 text-center text-gray-600">{formatNumber(stats.min)}</td>
                      <td className="py-3 px-4 text-center text-gray-600">{formatNumber(stats.max)}</td>
                      <td className="py-3 px-4 text-center text-gray-600">{formatNumber(stats['50%'])}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
              <h4 className="font-medium text-blue-800 mb-2">分析対象</h4>
              <p className="text-2xl font-bold text-blue-600">
                {Object.keys(analysisResult).length}
              </p>
              <p className="text-sm text-blue-700">数値列</p>
            </div>
            
            <div className="bg-green-50 border border-green-200 rounded-xl p-4">
              <h4 className="font-medium text-green-800 mb-2">データ数</h4>
              <p className="text-2xl font-bold text-green-600">
                {Object.values(analysisResult)[0]?.['count'] || 0}
              </p>
              <p className="text-sm text-green-700">レコード</p>
            </div>
            
            <div className="bg-purple-50 border border-purple-200 rounded-xl p-4">
              <h4 className="font-medium text-purple-800 mb-2">グラフ生成</h4>
              <p className="text-2xl font-bold text-purple-600">4</p>
              <p className="text-sm text-purple-700">種類</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BasicStatistics;
