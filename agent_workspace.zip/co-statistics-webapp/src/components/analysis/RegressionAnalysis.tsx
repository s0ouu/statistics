import React from 'react';
import { Layers } from 'lucide-react';

const RegressionAnalysis: React.FC = () => {
  return (
    <div className="p-6">
      <div className="flex items-center space-x-3 mb-6">
        <Layers className="text-indigo-500" size={28} />
        <div>
          <h2 className="text-2xl font-bold text-gray-800">回帰分析</h2>
          <p className="text-gray-600">変数間の関係性をモデル化</p>
        </div>
      </div>
      
      <div className="text-center py-12">
        <Layers className="mx-auto text-gray-300 mb-4" size={64} />
        <h3 className="text-lg font-medium text-gray-600 mb-2">回帰分析</h3>
        <p className="text-gray-500">準備中です...</p>
      </div>
    </div>
  );
};

export default RegressionAnalysis;
