import React from 'react';
import { Activity } from 'lucide-react';

const ProbabilityAnalysis: React.FC = () => {
  return (
    <div className="p-6">
      <div className="flex items-center space-x-3 mb-6">
        <Activity className="text-yellow-500" size={28} />
        <div>
          <h2 className="text-2xl font-bold text-gray-800">確率分析</h2>
          <p className="text-gray-600">確率分布とランダム性を分析</p>
        </div>
      </div>
      
      <div className="text-center py-12">
        <Activity className="mx-auto text-gray-300 mb-4" size={64} />
        <h3 className="text-lg font-medium text-gray-600 mb-2">確率分析</h3>
        <p className="text-gray-500">準備中です...</p>
      </div>
    </div>
  );
};

export default ProbabilityAnalysis;
