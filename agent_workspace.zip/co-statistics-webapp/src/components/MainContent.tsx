import React from 'react';
import { BarChart3, TrendingUp, Calculator, FileText, Activity, Layers } from 'lucide-react';
import WelcomeScreen from './WelcomeScreen';
import BasicStatistics from './analysis/BasicStatistics';
import TTestAnalysis from './analysis/TTestAnalysis';
import CovarianceAnalysis from './analysis/CovarianceAnalysis';
import ProbabilityAnalysis from './analysis/ProbabilityAnalysis';
import RegressionAnalysis from './analysis/RegressionAnalysis';
import ReportGeneration from './analysis/ReportGeneration';
import { useStatistics } from '../contexts/StatisticsContext';

interface MainContentProps {
  activeTab: string;
}

const MainContent: React.FC<MainContentProps> = ({ activeTab }) => {
  const { currentData, error } = useStatistics();

  const renderContent = () => {
    if (!currentData) {
      return <WelcomeScreen />;
    }

    switch (activeTab) {
      case 'basic':
        return <BasicStatistics />;
      case 'ttest':
        return <TTestAnalysis />;
      case 'covariance':
        return <CovarianceAnalysis />;
      case 'probability':
        return <ProbabilityAnalysis />;
      case 'regression':
        return <RegressionAnalysis />;
      case 'report':
        return <ReportGeneration />;
      default:
        return <BasicStatistics />;
    }
  };

  return (
    <main className="flex-1 overflow-y-auto bg-white/50 backdrop-blur-sm">
      <div className="p-6">
        {/* Error Banner */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl">
            <div className="flex items-center space-x-2">
              <div className="text-red-500">⚠️</div>
              <div>
                <h4 className="text-red-800 font-medium">エラーが発生しました</h4>
                <p className="text-red-600 text-sm mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Main Content */}
        <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg border border-white/20 min-h-[600px]">
          {renderContent()}
        </div>
      </div>
    </main>
  );
};

export default MainContent;
