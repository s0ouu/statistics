import React, { useState } from 'react';
import { CheckSquare, Square, Play, AlertTriangle } from 'lucide-react';
import { useStatistics } from '../contexts/StatisticsContext';

const DataCleaning: React.FC = () => {
  const { currentData, setIsLoading, setError } = useStatistics();
  const [selectedOptions, setSelectedOptions] = useState({
    basicStats: false,
    missingValues: false,
    outliers: false,
  });

  const cleaningOptions = [
    {
      id: 'basicStats',
      label: '基本統計情報',
      description: 'データの基本統計量を表示',
      icon: '📊',
    },
    {
      id: 'missingValues',
      label: '欠損値処理',
      description: '欠損値の検出と処理',
      icon: '🔍',
    },
    {
      id: 'outliers',
      label: '外れ値・データ修正',
      description: '外れ値の検出と修正',
      icon: '⚡',
    },
  ];

  const handleOptionToggle = (optionId: string) => {
    setSelectedOptions(prev => ({
      ...prev,
      [optionId]: !prev[optionId as keyof typeof prev],
    }));
  };

  const handleCleaning = async () => {
    if (!currentData) return;

    const selectedCount = Object.values(selectedOptions).filter(Boolean).length;
    if (selectedCount === 0) {
      setError('クリーニングオプションを選択してください');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Here you would call the cleaning API
      console.log('Running data cleaning with options:', selectedOptions);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Reset selections after successful cleaning
      setSelectedOptions({
        basicStats: false,
        missingValues: false,
        outliers: false,
      });
      
    } catch (error) {
      console.error('Cleaning error:', error);
      setError('データクリーニングエラーが発生しました');
    } finally {
      setIsLoading(false);
    }
  };

  if (!currentData) {
    return (
      <div className="text-center py-6 text-gray-500">
        <AlertTriangle className="mx-auto mb-2" size={24} />
        <p className="text-sm">データを読み込み後に利用可能</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Cleaning Options */}
      <div className="space-y-3">
        {cleaningOptions.map((option) => (
          <div
            key={option.id}
            onClick={() => handleOptionToggle(option.id)}
            className="flex items-center space-x-3 p-3 bg-white/50 rounded-lg border border-gray-200 cursor-pointer hover:bg-white/70 transition-colors"
          >
            <div className="flex-shrink-0">
              {selectedOptions[option.id as keyof typeof selectedOptions] ? (
                <CheckSquare className="text-purple-600" size={18} />
              ) : (
                <Square className="text-gray-400" size={18} />
              )}
            </div>
            
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <span className="text-lg">{option.icon}</span>
                <span className="text-sm font-medium text-gray-800">
                  {option.label}
                </span>
              </div>
              <p className="text-xs text-gray-600 mt-1">
                {option.description}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Execute Button */}
      <button
        onClick={handleCleaning}
        disabled={Object.values(selectedOptions).every(v => !v)}
        className={`
          w-full flex items-center justify-center space-x-2 py-3 rounded-lg font-medium text-sm transition-all duration-200
          ${Object.values(selectedOptions).some(v => v)
            ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 shadow-lg'
            : 'bg-gray-200 text-gray-400 cursor-not-allowed'
          }
        `}
      >
        <Play size={16} />
        <span>クリーニング実行</span>
      </button>

      {/* Data Summary */}
      <div className="bg-white/30 rounded-lg p-3 border border-gray-200">
        <h4 className="text-sm font-medium text-gray-800 mb-2">データサマリー</h4>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between">
            <span className="text-gray-600">欠損値:</span>
            <span className="font-medium">
              {Object.values(currentData.missing_values).reduce((sum, val) => sum + val, 0)}個
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">数値列:</span>
            <span className="font-medium">
              {Object.values(currentData.dtypes).filter(type => 
                type.includes('int') || type.includes('float')
              ).length}個
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">カテゴリ列:</span>
            <span className="font-medium">
              {Object.values(currentData.dtypes).filter(type => 
                type.includes('object') || type.includes('string')
              ).length}個
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataCleaning;
