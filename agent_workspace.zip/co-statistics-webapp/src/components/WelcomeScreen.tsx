import React from 'react';
import { BarChart3, Upload, TrendingUp, Zap, Database, Sparkles } from 'lucide-react';

const WelcomeScreen: React.FC = () => {
  const features = [
    {
      icon: <BarChart3 className="text-blue-500" size={24} />,
      title: '基本統計分析',
      description: 'データの分布、平均、分散など基本的な統計量を分析',
    },
    {
      icon: <TrendingUp className="text-green-500" size={24} />,
      title: 't検定・回帰分析',
      description: '仮説検定や変数間の関係性を統計的に分析',
    },
    {
      icon: <Zap className="text-purple-500" size={24} />,
      title: '高速データ処理',
      description: '大容量データも瞬時に処理し、美しいグラフで可視化',
    },
    {
      icon: <Sparkles className="text-yellow-500" size={24} />,
      title: 'インテリジェント推奨',
      description: 'データに最適な分析手法を自動で推奨',
    },
  ];

  const steps = [
    {
      number: '1',
      title: 'データをアップロード',
      description: 'CSV、Excelファイルをドラッグ&ドロップ',
      icon: <Upload className="text-blue-500" size={20} />,
    },
    {
      number: '2',
      title: '分析方法を選択',
      description: '目的に応じた統計分析を選択',
      icon: <Database className="text-purple-500" size={20} />,
    },
    {
      number: '3',
      title: '結果を確認',
      description: '美しいグラフと詳細な分析結果を表示',
      icon: <BarChart3 className="text-green-500" size={20} />,
    },
  ];

  return (
    <div className="p-8">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <div className="text-6xl mb-4">📊</div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent mb-4">
          Co-Statistics
        </h1>
        <p className="text-xl text-gray-600 mb-2">
          プロフェッショナル統計分析ツール
        </p>
        <p className="text-gray-500 max-w-2xl mx-auto">
          直感的なインターフェースで、複雑な統計分析を簡単に実行。
          データサイエンティストから研究者まで、あらゆる専門家のニーズに対応します。
        </p>
      </div>

      {/* Features Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {features.map((feature, index) => (
          <div
            key={index}
            className="bg-gradient-to-br from-white to-gray-50 rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-all duration-200 hover:scale-105"
          >
            <div className="mb-4">{feature.icon}</div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">
              {feature.title}
            </h3>
            <p className="text-sm text-gray-600">
              {feature.description}
            </p>
          </div>
        ))}
      </div>

      {/* How it Works */}
      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-8 border border-blue-100">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">
          簡単3ステップで始める
        </h2>
        
        <div className="grid md:grid-cols-3 gap-6">
          {steps.map((step, index) => (
            <div key={index} className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-white rounded-full shadow-lg mb-4">
                <span className="text-lg font-bold text-gray-800">{step.number}</span>
              </div>
              <div className="mb-3">{step.icon}</div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">
                {step.title}
              </h3>
              <p className="text-sm text-gray-600">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Call to Action */}
      <div className="text-center mt-12">
        <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl p-6 text-white">
          <h3 className="text-xl font-semibold mb-2">
            今すぐ分析を開始
          </h3>
          <p className="text-blue-100 mb-4">
            左側のサイドバーからデータファイルをアップロードして、統計分析を始めましょう
          </p>
          <div className="inline-flex items-center space-x-2 text-sm bg-white/20 rounded-lg px-4 py-2">
            <Upload size={16} />
            <span>CSV・Excelファイルに対応</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomeScreen;
