import React from 'react';
import { Clock, BarChart3, TrendingUp, Calculator, Eye, Trash2 } from 'lucide-react';
import { useStatistics } from '../contexts/StatisticsContext';

const AnalysisHistory: React.FC = () => {
  const { analysisHistory, setAnalysisHistory } = useStatistics();

  const getAnalysisIcon = (type: string) => {
    switch (type) {
      case '基本統計':
        return <BarChart3 size={14} className="text-blue-500" />;
      case 't検定':
        return <TrendingUp size={14} className="text-green-500" />;
      case '回帰分析':
        return <Calculator size={14} className="text-purple-500" />;
      default:
        return <BarChart3 size={14} className="text-gray-500" />;
    }
  };

  const handleViewResult = (analysisId: string) => {
    console.log('View analysis result:', analysisId);
    // Here you would implement viewing the analysis result
  };

  const handleDeleteResult = (analysisId: string) => {
    setAnalysisHistory(analysisHistory.filter(item => item.id !== analysisId));
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString('ja-JP', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (analysisHistory.length === 0) {
    return (
      <div className="text-center py-6 text-gray-500">
        <Clock className="mx-auto mb-2" size={24} />
        <p className="text-sm">分析履歴がありません</p>
        <p className="text-xs text-gray-400 mt-1">
          分析を実行すると履歴が表示されます
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3 max-h-64 overflow-y-auto">
      {analysisHistory.map((item) => (
        <div
          key={item.id}
          className="bg-white/50 rounded-lg p-3 border border-gray-200 hover:bg-white/70 transition-colors"
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              {getAnalysisIcon(item.type)}
              <span className="text-sm font-medium text-gray-800">
                {item.type}
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <button
                onClick={() => handleViewResult(item.id)}
                className="p-1 text-gray-400 hover:text-blue-500 transition-colors"
                title="結果を表示"
              >
                <Eye size={12} />
              </button>
              <button
                onClick={() => handleDeleteResult(item.id)}
                className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                title="削除"
              >
                <Trash2 size={12} />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="space-y-2">
            <p className="text-xs text-gray-600">
              {item.summary}
            </p>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-1 text-xs text-gray-500">
                <Clock size={10} />
                <span>{formatTimestamp(item.timestamp)}</span>
              </div>
              
              {item.chart_url && (
                <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">
                  グラフ有
                </span>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AnalysisHistory;
