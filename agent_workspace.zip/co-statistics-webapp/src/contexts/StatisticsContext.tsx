import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface DataInfo {
  rows: number;
  columns: number;
  column_names: string[];
  dtypes: Record<string, string>;
  missing_values: Record<string, number>;
  preview: Record<string, any>[];
}

export interface AnalysisResult {
  id: string;
  type: string;
  timestamp: string;
  chart_url?: string;
  summary: string;
  stats?: Record<string, any>;
}

interface StatisticsContextType {
  currentData: DataInfo | null;
  setCurrentData: (data: DataInfo | null) => void;
  analysisHistory: AnalysisResult[];
  setAnalysisHistory: (history: AnalysisResult[]) => void;
  addAnalysisResult: (result: AnalysisResult) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  error: string | null;
  setError: (error: string | null) => void;
}

const StatisticsContext = createContext<StatisticsContextType | undefined>(undefined);

export const useStatistics = () => {
  const context = useContext(StatisticsContext);
  if (context === undefined) {
    throw new Error('useStatistics must be used within a StatisticsProvider');
  }
  return context;
};

interface StatisticsProviderProps {
  children: ReactNode;
}

export const StatisticsProvider: React.FC<StatisticsProviderProps> = ({ children }) => {
  const [currentData, setCurrentData] = useState<DataInfo | null>(null);
  const [analysisHistory, setAnalysisHistory] = useState<AnalysisResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const addAnalysisResult = (result: AnalysisResult) => {
    setAnalysisHistory(prev => [result, ...prev]);
  };

  const value: StatisticsContextType = {
    currentData,
    setCurrentData,
    analysisHistory,
    setAnalysisHistory,
    addAnalysisResult,
    isLoading,
    setIsLoading,
    error,
    setError,
  };

  return (
    <StatisticsContext.Provider value={value}>
      {children}
    </StatisticsContext.Provider>
  );
};
