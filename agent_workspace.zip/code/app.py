#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Co-Statistics 統計分析ツール
作成者: MiniMax Agent
"""

import os
import json
import uuid
from datetime import datetime
import pandas as pd
import numpy as np
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
# import plotly.express as px
# import plotly.graph_objects as go
# from plotly.utils import PlotlyJSONEncoder
# from sklearn.linear_model import LinearRegression
# from sklearn.preprocessing import StandardScaler
from flask import Flask, render_template, request, jsonify, send_file
import warnings
warnings.filterwarnings('ignore')

def setup_matplotlib_for_plotting():
    """
    matplotlibの設定を行う
    """
    import warnings
    import matplotlib.pyplot as plt
    import seaborn as sns

    warnings.filterwarnings('default')
    plt.switch_backend("Agg")
    plt.style.use("seaborn-v0_8")
    sns.set_palette("husl")
    plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC", "WenQuanYi Zen Hei", "PingFang SC", "Arial Unicode MS", "Hiragino Sans GB"]
    plt.rcParams["axes.unicode_minus"] = False

app = Flask(__name__, template_folder='../templates', static_folder='../static')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# グローバルデータストレージ
current_data = None
analysis_history = []

@app.route('/')
def index():
    """メインページの表示"""
    return render_template('index.html')

@app.route('/api/upload', methods=['POST'])
def upload_file():
    """ファイルアップロード処理"""
    global current_data
    
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'ファイルが選択されていません'})
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'error': 'ファイルが選択されていません'})
        
        # ファイル形式の確認
        if file.filename.endswith('.csv'):
            current_data = pd.read_csv(file, encoding='utf-8')
        elif file.filename.endswith('.xlsx') or file.filename.endswith('.xls'):
            current_data = pd.read_excel(file)
        else:
            return jsonify({'success': False, 'error': 'サポートされていないファイル形式です (CSV, Excel のみ)'})
        
        # データの基本情報を取得
        data_info = {
            'rows': len(current_data),
            'columns': len(current_data.columns),
            'column_names': current_data.columns.tolist(),
            'dtypes': current_data.dtypes.astype(str).to_dict(),
            'missing_values': current_data.isnull().sum().to_dict(),
            'preview': current_data.head().to_dict(orient='records')
        }
        
        return jsonify({
            'success': True, 
            'message': 'ファイルが正常にアップロードされました',
            'data_info': data_info
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': f'ファイル処理エラー: {str(e)}'})

@app.route('/api/basic_stats', methods=['POST'])
def basic_statistics():
    """基本統計分析"""
    global current_data, analysis_history
    
    try:
        if current_data is None:
            return jsonify({'success': False, 'error': 'データが読み込まれていません'})
        
        # 数値列の取得
        numeric_columns = current_data.select_dtypes(include=[np.number]).columns
        
        if len(numeric_columns) == 0:
            return jsonify({'success': False, 'error': '数値データが見つかりません'})
        
        # 基本統計量の計算
        stats_data = current_data[numeric_columns].describe()
        
        # グラフの作成
        setup_matplotlib_for_plotting()
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        fig.suptitle('基本統計分析', fontsize=16)
        
        # ヒストグラム
        if len(numeric_columns) >= 1:
            current_data[numeric_columns[0]].hist(bins=20, ax=axes[0,0])
            axes[0,0].set_title(f'{numeric_columns[0]} の分布')
        
        # 散布図（2つの数値列がある場合）
        if len(numeric_columns) >= 2:
            axes[0,1].scatter(current_data[numeric_columns[0]], current_data[numeric_columns[1]])
            axes[0,1].set_xlabel(numeric_columns[0])
            axes[0,1].set_ylabel(numeric_columns[1])
            axes[0,1].set_title('散布図')
        
        # 箱ひげ図
        if len(numeric_columns) >= 1:
            current_data[numeric_columns[:min(3, len(numeric_columns))]].boxplot(ax=axes[1,0])
            axes[1,0].set_title('箱ひげ図')
        
        # 相関マトリックス
        if len(numeric_columns) >= 2:
            corr_matrix = current_data[numeric_columns].corr()
            im = axes[1,1].imshow(corr_matrix, cmap='coolwarm', aspect='auto')
            axes[1,1].set_title('相関マトリックス')
            axes[1,1].set_xticks(range(len(corr_matrix.columns)))
            axes[1,1].set_yticks(range(len(corr_matrix.columns)))
            axes[1,1].set_xticklabels(corr_matrix.columns, rotation=45)
            axes[1,1].set_yticklabels(corr_matrix.columns)
            plt.colorbar(im, ax=axes[1,1])
        
        plt.tight_layout()
        
        # 画像の保存
        chart_filename = f'basic_stats_{uuid.uuid4().hex[:8]}.png'
        chart_path = f'/workspace/static/{chart_filename}'
        plt.savefig(chart_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        # 履歴に追加
        analysis_record = {
            'id': str(uuid.uuid4()),
            'type': '基本統計',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'chart_url': f'/static/{chart_filename}',
            'summary': f'{len(numeric_columns)}個の数値列を分析'
        }
        analysis_history.append(analysis_record)
        
        return jsonify({
            'success': True,
            'stats': stats_data.to_dict(),
            'chart_url': f'/static/{chart_filename}',
            'analysis_id': analysis_record['id']
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': f'分析エラー: {str(e)}'})

@app.route('/api/t_test', methods=['POST'])
def t_test_analysis():
    """t検定分析"""
    global current_data, analysis_history
    
    try:
        if current_data is None:
            return jsonify({'success': False, 'error': 'データが読み込まれていません'})
        
        data = request.json
        column1 = data.get('column1')
        column2 = data.get('column2', None)
        test_type = data.get('test_type', 'one_sample')
        
        numeric_columns = current_data.select_dtypes(include=[np.number]).columns
        
        if column1 not in numeric_columns:
            return jsonify({'success': False, 'error': f'{column1} は数値列ではありません'})
        
        if test_type == 'one_sample':
            # 一標本t検定
            test_value = data.get('test_value', 0)
            t_stat, p_value = stats.ttest_1samp(current_data[column1].dropna(), test_value)
            test_description = f'{column1} の平均が {test_value} と等しいかの検定'
            
        elif test_type == 'two_sample':
            # 二標本t検定
            if column2 not in numeric_columns:
                return jsonify({'success': False, 'error': f'{column2} は数値列ではありません'})
            
            data1 = current_data[column1].dropna()
            data2 = current_data[column2].dropna()
            t_stat, p_value = stats.ttest_ind(data1, data2)
            test_description = f'{column1} と {column2} の平均の差の検定'
        
        # 結果の解釈
        significance = 'あり' if p_value < 0.05 else 'なし'
        
        # グラフの作成
        setup_matplotlib_for_plotting()
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        
        if test_type == 'one_sample':
            current_data[column1].hist(bins=20, ax=axes[0], alpha=0.7)
            axes[0].axvline(current_data[column1].mean(), color='red', linestyle='--', label='標本平均')
            axes[0].axvline(test_value, color='blue', linestyle='--', label='検定値')
            axes[0].set_title(f'{column1} の分布')
            axes[0].legend()
            
        elif test_type == 'two_sample':
            current_data[column1].hist(bins=20, ax=axes[0], alpha=0.7, label=column1)
            current_data[column2].hist(bins=20, ax=axes[0], alpha=0.7, label=column2)
            axes[0].set_title('分布の比較')
            axes[0].legend()
        
        # t分布の描画
        df = len(current_data[column1].dropna()) - 1
        x = np.linspace(-4, 4, 100)
        y = stats.t.pdf(x, df)
        axes[1].plot(x, y, 'b-', label=f't分布 (df={df})')
        axes[1].axvline(t_stat, color='red', linestyle='--', label=f't統計量 = {t_stat:.3f}')
        axes[1].set_title('t検定結果')
        axes[1].legend()
        
        plt.tight_layout()
        
        # 画像の保存
        chart_filename = f't_test_{uuid.uuid4().hex[:8]}.png'
        chart_path = f'/workspace/static/{chart_filename}'
        plt.savefig(chart_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        # 履歴に追加
        analysis_record = {
            'id': str(uuid.uuid4()),
            'type': 't検定',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'chart_url': f'/static/{chart_filename}',
            'summary': f'{test_description} (p値: {p_value:.4f})'
        }
        analysis_history.append(analysis_record)
        
        return jsonify({
            'success': True,
            'results': {
                't_statistic': t_stat,
                'p_value': p_value,
                'significance': significance,
                'description': test_description
            },
            'chart_url': f'/static/{chart_filename}',
            'analysis_id': analysis_record['id']
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': f't検定エラー: {str(e)}'})

@app.route('/api/regression', methods=['POST'])
def regression_analysis():
    """回帰分析"""
    global current_data, analysis_history
    
    try:
        if current_data is None:
            return jsonify({'success': False, 'error': 'データが読み込まれていません'})
        
        data = request.json
        x_column = data.get('x_column')
        y_column = data.get('y_column')
        
        numeric_columns = current_data.select_dtypes(include=[np.number]).columns
        
        if x_column not in numeric_columns or y_column not in numeric_columns:
            return jsonify({'success': False, 'error': '選択された列が数値列ではありません'})
        
        # データの準備
        df_clean = current_data[[x_column, y_column]].dropna()
        X = df_clean[x_column].values.reshape(-1, 1)
        y = df_clean[y_column].values
        
        # 線形回帰の実行
        model = LinearRegression()
        model.fit(X, y)
        
        # 予測値の計算
        y_pred = model.predict(X)
        
        # 統計量の計算
        r_squared = model.score(X, y)
        correlation = df_clean[x_column].corr(df_clean[y_column])
        
        # グラフの作成
        setup_matplotlib_for_plotting()
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        fig.suptitle('回帰分析結果', fontsize=16)
        
        # 散布図と回帰直線
        axes[0,0].scatter(X, y, alpha=0.6)
        axes[0,0].plot(X, y_pred, 'r-', linewidth=2)
        axes[0,0].set_xlabel(x_column)
        axes[0,0].set_ylabel(y_column)
        axes[0,0].set_title(f'回帰分析 (R² = {r_squared:.3f})')
        
        # 残差プロット
        residuals = y - y_pred
        axes[0,1].scatter(y_pred, residuals, alpha=0.6)
        axes[0,1].axhline(y=0, color='r', linestyle='--')
        axes[0,1].set_xlabel('予測値')
        axes[0,1].set_ylabel('残差')
        axes[0,1].set_title('残差プロット')
        
        # QQプロット
        stats.probplot(residuals, dist="norm", plot=axes[1,0])
        axes[1,0].set_title('残差のQQプロット')
        
        # 残差のヒストグラム
        axes[1,1].hist(residuals, bins=20, alpha=0.7)
        axes[1,1].set_xlabel('残差')
        axes[1,1].set_ylabel('頻度')
        axes[1,1].set_title('残差の分布')
        
        plt.tight_layout()
        
        # 画像の保存
        chart_filename = f'regression_{uuid.uuid4().hex[:8]}.png'
        chart_path = f'/workspace/static/{chart_filename}'
        plt.savefig(chart_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        # 履歴に追加
        analysis_record = {
            'id': str(uuid.uuid4()),
            'type': '回帰分析',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'chart_url': f'/static/{chart_filename}',
            'summary': f'{x_column} → {y_column} (R² = {r_squared:.3f})'
        }
        analysis_history.append(analysis_record)
        
        return jsonify({
            'success': True,
            'results': {
                'coefficient': model.coef_[0],
                'intercept': model.intercept_,
                'r_squared': r_squared,
                'correlation': correlation,
                'equation': f'y = {model.coef_[0]:.3f}x + {model.intercept_:.3f}'
            },
            'chart_url': f'/static/{chart_filename}',
            'analysis_id': analysis_record['id']
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': f'回帰分析エラー: {str(e)}'})

@app.route('/api/data_cleaning', methods=['POST'])
def data_cleaning():
    """データクリーニング"""
    global current_data
    
    try:
        if current_data is None:
            return jsonify({'success': False, 'error': 'データが読み込まれていません'})
        
        data = request.json
        operation = data.get('operation')
        
        if operation == 'remove_missing':
            # 欠損値の削除
            initial_rows = len(current_data)
            current_data = current_data.dropna()
            removed_rows = initial_rows - len(current_data)
            message = f'{removed_rows}行の欠損値を削除しました'
            
        elif operation == 'fill_missing':
            # 欠損値の補完
            fill_method = data.get('fill_method', 'mean')
            numeric_columns = current_data.select_dtypes(include=[np.number]).columns
            
            for col in numeric_columns:
                if fill_method == 'mean':
                    current_data[col].fillna(current_data[col].mean(), inplace=True)
                elif fill_method == 'median':
                    current_data[col].fillna(current_data[col].median(), inplace=True)
                elif fill_method == 'mode':
                    current_data[col].fillna(current_data[col].mode()[0], inplace=True)
            
            message = f'{fill_method}法で欠損値を補完しました'
            
        elif operation == 'remove_outliers':
            # 外れ値の除去（IQR法）
            numeric_columns = current_data.select_dtypes(include=[np.number]).columns
            initial_rows = len(current_data)
            
            for col in numeric_columns:
                Q1 = current_data[col].quantile(0.25)
                Q3 = current_data[col].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                current_data = current_data[(current_data[col] >= lower_bound) & (current_data[col] <= upper_bound)]
            
            removed_rows = initial_rows - len(current_data)
            message = f'{removed_rows}行の外れ値を除去しました'
        
        # 現在のデータ情報を取得
        data_info = {
            'rows': len(current_data),
            'columns': len(current_data.columns),
            'missing_values': current_data.isnull().sum().to_dict(),
            'preview': current_data.head().to_dict(orient='records')
        }
        
        return jsonify({
            'success': True,
            'message': message,
            'data_info': data_info
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': f'データクリーニングエラー: {str(e)}'})

@app.route('/api/history', methods=['GET'])
def get_analysis_history():
    """分析履歴の取得"""
    return jsonify({'success': True, 'history': analysis_history})

@app.route('/api/recommendations', methods=['GET'])
def get_recommendations():
    """次の分析のレコメンデーション"""
    global current_data, analysis_history
    
    try:
        if current_data is None:
            return jsonify({'success': True, 'recommendations': []})
        
        recommendations = []
        numeric_columns = current_data.select_dtypes(include=[np.number]).columns
        
        # 実行済み分析の種類を確認
        completed_analyses = [record['type'] for record in analysis_history]
        
        # 基本統計が未実行の場合
        if '基本統計' not in completed_analyses and len(numeric_columns) > 0:
            recommendations.append({
                'type': '基本統計',
                'title': '基本統計分析の実行',
                'description': 'データの基本的な統計量を確認することをお勧めします',
                'priority': 'high'
            })
        
        # 相関分析の提案
        if len(numeric_columns) >= 2 and '相関分析' not in completed_analyses:
            recommendations.append({
                'type': '相関分析',
                'title': '変数間の相関分析',
                'description': '数値変数間の関係性を調べることができます',
                'priority': 'medium'
            })
        
        # 回帰分析の提案
        if len(numeric_columns) >= 2 and '回帰分析' not in completed_analyses:
            recommendations.append({
                'type': '回帰分析',
                'title': '回帰分析の実行',
                'description': '変数間の因果関係をモデル化できます',
                'priority': 'medium'
            })
        
        # データクリーニングの提案
        missing_values = current_data.isnull().sum().sum()
        if missing_values > 0:
            recommendations.append({
                'type': 'データクリーニング',
                'title': 'データクリーニング',
                'description': f'{missing_values}個の欠損値が見つかりました。クリーニングをお勧めします',
                'priority': 'high'
            })
        
        return jsonify({'success': True, 'recommendations': recommendations})
        
    except Exception as e:
        return jsonify({'success': False, 'error': f'レコメンデーションエラー: {str(e)}'})

@app.route('/api/columns', methods=['GET'])
def get_columns():
    """列名の取得"""
    global current_data
    
    if current_data is None:
        return jsonify({'success': False, 'error': 'データが読み込まれていません'})
    
    numeric_columns = current_data.select_dtypes(include=[np.number]).columns.tolist()
    all_columns = current_data.columns.tolist()
    
    return jsonify({
        'success': True,
        'numeric_columns': numeric_columns,
        'all_columns': all_columns
    })

if __name__ == '__main__':
    # staticフォルダの作成
    os.makedirs('/workspace/static', exist_ok=True)
    app.run(host='0.0.0.0', port=5001, debug=True)
